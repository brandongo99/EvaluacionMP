import Layout from "../components/Layout";
import { useEffect, useState } from 'react';
import { Table } from 'react-bootstrap';
import api from "../utils/axiosInstance";
import { format } from 'date-fns';

const Dashboard = () => {
  const empleado = JSON.parse(localStorage.getItem("empleado"));
  const [periodos, setPeriodos] = useState([]);

  useEffect(() => {
      try {
        cargarPeriodos();
      } catch (error) {
        console.error("Error:", error);
      }
    }, []);

  const cargarPeriodos = async () => {
    try {
      const response = await api.get(
        `/ausencias/sel-periodos?empresa=${empleado.em_Company}&noEmpleado=${empleado.em_No}`
      );

      setPeriodos(response.data);
    } catch (error) {
      console.error("Error al obtener los periodos:", error);
      setPeriodos([]);
    }
  };

  return (
    <Layout>
      <div className="p-3 container-fluid">
        <div className="row">
          <div className="col-lg-12 col-md-12 col-12">
            <div className="border-bottom pb-4 mb-4">
              <h3 className="mb-0 fw-bold">Bienvenido, {empleado?.em_Name}</h3>
            </div>
          </div>
        </div>        
      </div>      
      {/* Tabla de periodos */}
      <div className="p-3 container-fluid">
        <div className="card">
          <div className="card-body">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div className="mb-4">
                  <h3>Periodos Vacaciones</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <Table responsive hover className="text-nowrap">
                <thead className="table-light">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Periodo Inicio</th>
                    <th scope="col">Periodo Fin</th>
                    <th scope="col">Días Acumulados</th>
                    <th scope="col">Días Gozados</th>
                    <th scope="col">Días Pendientes</th>
                  </tr>
                </thead>
                <tbody>
                  {periodos.map((periodo, index) => (
                    <tr key={index}>
                      <th scope="row">{index + 1}</th>
                      <td>{format(new Date(periodo.periodoInicio), "dd/MM/yyyy")}</td>
                      <td>{format(new Date(periodo.periodoFin), "dd/MM/yyyy")}</td>
                      <td>{periodo.diasAcumulados}</td>
                      <td>{periodo.diasGozados}</td>
                      <td>{periodo.diasPendientes}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;
