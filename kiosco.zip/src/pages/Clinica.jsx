import Layout from "../components/Layout";
import { DatePicker, SelectPicker } from 'rsuite';
import { Button, Table } from 'react-bootstrap';
import { Pocket } from 'react-feather';
import { useEffect, useState, useRef } from 'react';
import { isBefore, startOfToday, format } from 'date-fns';
import { showAlert, showAlertWithTimer } from '../utils/Alerts';
import api from "../utils/axiosInstance";
import 'rsuite/dist/rsuite.min.css';
import PaginatedComponent from '../components/Pagination';

const Clinica = () => {
  const empleado = JSON.parse(localStorage.getItem("empleado"));  

  const [fecha, setFecha] = useState(new Date());
  const [horas, setHoras] = useState([]);
  const [horaSeleccionada, setHoraSeleccionada] = useState(null);
  const [nota, setNota] = useState("");
  const [citas, setCitas] = useState([]);
  const [guardando, setGuardando] = useState(false);
  const [guardar, setGuardar] = useState(false);
  const [valido, setValido] = useState(false);
  const textareaRef = useRef();

  const cargarCitas = async () => {
    try {
      const response = await api.get(
        `/clinica/sel-citas/${empleado.em_No}`
      );
      setCitas(response.data);
    } catch (error) {
      console.error("Error al obtener las citas:", error);
      setCitas([]);
    }
  };

  const cargarHorarios = async () => {
    try {
      const fechaFormateada = format(fecha, "dd-MM-yyyy");
      const response = await api.get(`/clinica/sel-horarios/${fechaFormateada}`);
      const opciones = response.data.map((item) => ({
        label: item.horario,
        value: item.hora,
      }));
      setHoras(opciones);
    } catch (error) {
      console.error("Error al obtener horarios:", error);
      showAlert('error', '¡Error!', error.message);
      setHoras([]);
    }
  };

  useEffect(() => {
    try {
      cargarHorarios();
    } catch (error) {
      console.error("Error:", error);
    }
  }, [fecha]);

  useEffect(() => {
    try {
      cargarHorarios();
      cargarCitas();
      setGuardar(false);
    } catch (error) {
      console.error("Error:", error);
    }
  }, [guardar]);

  const handleGuardar = async () => {
    setGuardando(true);
    setValido(true);

    if (!horaSeleccionada) {
      showAlert('warning', 'Hora requerida', 'Debe seleccionar una hora.');
      setGuardando(false);
      setValido(false);
      return;
    }    

    const fechaConHora = new Date(fecha);
    const [hora, minutos, segundos] = horaSeleccionada.split(":");
    fechaConHora.setHours(hora, minutos, segundos);

    const cita = {
      noEmpleado: empleado?.em_No,
      fechaCita: format(fechaConHora, "yyyy-MM-dd'T'HH:mm:ss"),
      nota: nota,
      usuarioIU: "KIOSCO",
      nombre: empleado?.em_Name
    };

    try {
      api.post("/clinica/i-cita", cita);
      showAlertWithTimer('success', '¡Éxito!', 'La cita fue registrada.');
      resetFormulario();
      cargarCitas();
    } catch (error) {
      showAlert('error', '¡Error!', 'Ocurrió un error al guardar la cita.');
    } finally {
      setGuardando(false);
      setGuardar(true);
      setValido(false);
    }
  };

  const handleNotaChange = (e) => {
    setNota(e.target.value);

    const el = textareaRef.current;
    el.style.height = "auto";
    el.style.height = el.scrollHeight + "px";
  };

  const resetFormulario = () => {
    setFecha(new Date());
    setHoraSeleccionada(null);
    setNota("");
    textareaRef.current.style.height = "auto";
  };

  return (
    <Layout>
      <div className="p-3 container-fluid">
        <div className="row">
          <div className="col-lg-12 col-md-12 col-12">
            <div className="border-bottom pb-4 mb-4">
              <h3 className="mb-0 fw-bold">Clínica Médica</h3>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="card-body">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div className="mb-4">
                  <h3>Crear Cita</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Código</label>
                  <input type="text" className="form-control" value={empleado?.em_No} readOnly />
                </div>
              </div>
              <div className="col-sm-3">
                <div className="form-group">
                  <label className="form-label">Nombre</label>
                  <input type="text" className="form-control" value={empleado?.em_Name} readOnly />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Fecha (*)</label>
                  <DatePicker
                    defaultValue={new Date()}
                    shouldDisableDate={date => isBefore(date, startOfToday())}
                    value={fecha}
                    onChange={setFecha}
                    cleanable={false}
                    oneTap
                    format="dd/MM/yyyy"
                    placement="bottomStart"
                  />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Hora (*)</label>
                  <SelectPicker
                    data={horas}
                    value={horaSeleccionada}
                    onChange={setHoraSeleccionada}
                    searchable={false}
                    cleanable={false}
                    placeholder="Seleccionar hora..."
                  />
                </div>
              </div>
              <div className="col-sm-3">
                <div className="form-group">
                  <label className="form-label">Nota</label>
                  <textarea
                    ref={textareaRef}
                    className="form-control"
                    rows="1"
                    value={nota}
                    onChange={handleNotaChange}
                  />
                </div>
              </div>
            </div>
            <div className="row mt-4">
              <div className="col-sm-4 d-grid mx-auto">
                <Button
                  disabled={valido}
                  type="submit"
                  variant="outline-success"
                  className="mb-2 me-1"
                  onClick={handleGuardar}
                >{guardando ? 'Guardando...' : <>Grabar <Pocket size="18px" /></>}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Tabla de citas */}
      <div className="p-3 container-fluid">
        <div className="card">
          <div className="card-body">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div className="mb-4">
                  <h3>Citas Creadas</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <PaginatedComponent
                data={citas}
                itemsPerPage={15}
                renderItems={(currentItems) => (
                  <Table responsive hover className="text-nowrap">
                    <thead className="table-light">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Fecha Cita</th>
                        <th scope="col">Fecha Creada</th>
                        <th scope="col">Cerrada</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentItems.map((cita, index) => (
                        <tr key={index}>
                          <th scope="row">{index + 1}</th>
                          <td>{cita.nombre}</td>
                          <td>{format(new Date(cita.fechaCita), "dd/MM/yyyy HH:mm")}</td>
                          <td>{format(new Date(cita.fechaCreada), "dd/MM/yyyy HH:mm")}</td>
                          <td>{cita.cerrada}</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )}
              />              
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Clinica;
