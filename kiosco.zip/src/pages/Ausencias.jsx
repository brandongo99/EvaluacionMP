import Layout from "../components/Layout";
import { DatePicker, SelectPicker } from 'rsuite';
import { Button, Table } from 'react-bootstrap';
import { Pocket } from 'react-feather';
import { useEffect, useState } from 'react';
import { isBefore, isAfter, startOfToday, startOfDay, addDays, format } from 'date-fns';
import { showAlert, showAlertWithTimer } from '../utils/Alerts';
import api from "../utils/axiosInstance";
import 'rsuite/dist/rsuite.min.css';
import PaginatedComponent from '../components/Pagination';

const Ausencias = () => {
  const empleado = JSON.parse(localStorage.getItem("empleado"));

  const [codGerente, setCodGerente] = useState("");
  const [nombreGerente, setNombreGerente] = useState("");
  const [motivos, setMotivos] = useState([]);
  const [motivoSeleccionado, setMotivoSeleccionado] = useState(null);
  const [tipos, setTipos] = useState([]);
  const [tipoSeleccionado, setTipoSeleccionado] = useState(null);
  const [detalle, setDetalle] = useState("");
  const [fechaInicial, setFechaInicial] = useState(null);
  const [fechaFinal, setFechaFinal] = useState(null);
  const [diasHabiles, setDiasHabiles] = useState(0);
  const [guardando, setGuardando] = useState(false);
  const [valido, setValido] = useState(false);
  const [ausencias, setAusencias] = useState([]);
  const [diasPeriodo, setDiasPeriodo] = useState(0);
  const [diasTotal, setDiasTotal] = useState(0);
  const [periodos, setPeriodos] = useState([]);
  const [guardar, setGuardar] = useState(false);
  const [pFechaInicial, setPFechaInicial] = useState(null);
  const [pFechaFinal, setPFechaFinal] = useState(null);

  const obtenerPSTGerente = async () => {
    try {
      const response = await api.get(
        `/empleados/${empleado.em_Company}/gerente-nivel2?seccion=${empleado.em_CodArea}`
      );

      setCodGerente(response.data[0].codigo);
      setNombreGerente(response.data[0].nombre);
    } catch (error) {
      console.error("Error al obtener Puesto Gerente:", error);
    }
  };

  const cargarMotivos = async () => {
    try {
      const response = await api.get("/ausencias/sel-motivos");
      const opciones = response.data.map((item) => ({
        label: item.descripcion,
        value: item.motivo,
      }));
      setMotivos(opciones);
    } catch (error) {
      console.error("Error al obtener motivos:", error);
      showAlert('error', '¡Error!', error.message);
      setMotivos([]);
    }
  }

  const cargarTipos = async () => {
    try {
      const response = await api.get("/ausencias/sel-tipos-permiso");
      const opciones = response.data.map((item) => ({
        label: item.descripcion,
        value: item.tipo,
      }));
      setTipos(opciones);
    } catch (error) {
      console.error("Error al obtener tipos:", error);
      showAlert('error', '¡Error!', error.message);
      setTipos([]);
    }
  }

  const cargarAusencias = async () => {
    try {
      const response = await api.get(
        `/ausencias/sel-ausencias-permisos?codEmpleado=${empleado.em_No}&usuario=${empleado.em_No}`
      );
      setAusencias(response.data);
    } catch (error) {
      console.error("Error al obtener las ausencias:", error);
      setAusencias([]);
    }
  };

  const cargarPeriodos = async () => {
    try {
      const response = await api.get(
        `/ausencias/sel-periodos?empresa=${empleado.em_Company}&noEmpleado=${empleado.em_No}`
      );

      const periodosFiltrados = response.data.filter(item => item.diasPendientes > 0);
      const primerPeriodo = periodosFiltrados[0];

      if (primerPeriodo) {
        const periodoDias = primerPeriodo.diasPendientes;
        const periodoInicio = primerPeriodo.periodoInicio;
        const periodoFin = primerPeriodo.periodoFin;

        setPeriodos(response.data);
        setDiasPeriodo(periodoDias);
        setDiasTotal(response.data.reduce((total, item) => total + item.diasPendientes, 0));
        setPFechaInicial(periodoInicio);
        setPFechaFinal(periodoFin);

        if (periodoDias < 1) {
          showAlert('error', '¡Error!', 'No tiene días disponibles de vacaciones.');
          setValido(true);
        }
      } else {
        showAlert('error', '¡Error!', 'No tiene días disponibles de vacaciones.');
        setValido(true);
      }
    } catch (error) {
      console.error("Error al obtener los periodos:", error);
      setPeriodos([]);
    }
  };

  useEffect(() => {
    try {
      obtenerPSTGerente();
      cargarMotivos();
      setMotivoSeleccionado(6);
      cargarTipos();
      setTipoSeleccionado(3);
      setDetalle("VACACIONES");
      cargarAusencias();
      cargarPeriodos();
      setGuardar(false);

      if (!empleado?.em_CodJefe) {
        showAlert('error', '¡Error!', 'No se pudo obtener los datos del jefe. Por favor, repórtelo con Recursos Humanos.')
        setValido(true);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  }, [guardar]);

  useEffect(() => {
    if (fechaInicial && fechaFinal) {
      calcularDias();
    }
  }, [fechaInicial, fechaFinal]);

  const calcularDias = () => {
    const inicio = startOfDay(new Date(fechaInicial));
    const fin = startOfDay(new Date(fechaFinal));
    let dias = 0;

    if (isAfter(inicio, fin)) {
      showAlert('error', '¡Error!', 'La fecha inicial no puede ser mayor que la fecha final.');
      resetFormulario();
      return;
    }

    let fechaActual = inicio;

    while (isBefore(fechaActual, addDays(fin, 1))) {
      const dia = fechaActual.getDay();
      if (dia !== 0 && dia !== 6) {
        dias++;
      }
      fechaActual.setDate(fechaActual.getDate() + 1);
    }
    setDiasHabiles(dias);

    if (dias > diasPeriodo) {
      showAlert('error', '¡Error!', 'No tiene suficientes días disponibles para el periodo.');
      resetFormulario();
      return;
    }

    showAlertWithTimer('warning', '¡Aviso!', 'Si su rango de fechas contiene días festivos, deben ser validados por su Coordinador de Gente.');
  };

  const handleGuardar = async () => {
    setGuardando(true);
    setValido(true);

    if (!fechaInicial || !fechaFinal) {
      showAlert('warning', 'Fechas requerida', 'Debe seleccionar fecha inicial y final.');
      setGuardando(false);
      setValido(false);
      return;
    }

    const fechaInicio = format(fechaInicial, "dd-MM-yyyy");
    const fechaFin = format(fechaFinal, "dd-MM-yyyy");

    const validar = await api.get(`/ausencias/sel-vacaciones?NoEmpleado=${empleado?.em_No}&FechaInicio=${fechaInicio}&FechaFin=${fechaFin}`);

    if (validar.data && validar.data.vacaciones != 0) {
      showAlert('error', '¡Fechas Duplicadas!', 'Ya existen vacaciones creadas para las fechas específicadas, favor validar.');
      resetFormulario();
      setGuardando(false);
      setValido(false);
      return;
    }

    const response = await api.get("/empleados/datos?puesto=PST-800007");

    const ausencia = {
      ausencia: null,
      empresa: empleado?.em_Company,
      noEmpleado: empleado?.em_No,
      codJefe: empleado?.em_CodJefe,
      codGerente: !codGerente ? empleado?.em_CodJefe : codGerente,
      motivo: motivoSeleccionado,
      motivo2: null,
      tipoPermiso: tipoSeleccionado,
      detalle: detalle,
      fechaInicio: format(fechaInicial, "yyyy-MM-dd"),
      fechaFin: format(fechaFinal, "yyyy-MM-dd"),
      dias: diasHabiles,
      horaEntrada: null,
      horaSalida: null,
      horas: null,
      codAutorizador_1: response?.data[0].em_No ? response.data[0].em_No : null,
      codAutorizador_2: null,
      descuento: false,
      estado: 0,
      usuarioIU: "KIOSCO"
    };

    try {
      const guardar = await api.post("/ausencias/iu-ausencias-permisos", ausencia);
      showAlertWithTimer('success', '¡Éxito!', 'La ausencia fue registrada. Debe solicitar la aprobación a su Jefe Inmediato.');
      await enviarCorreo(guardar);
      await imprimir(guardar);
      resetFormulario();
    } catch (error) {
      showAlert('error', '¡Error!', 'Ocurrió un error al guardar la ausencia.');
    } finally {
      setGuardando(false);
      setGuardar(true);
      setValido(false);
    }
  };

  const imprimir = async (guardar) => {
    try {
      const response = await api.get(`/ausencias/rpt-ausencias?ausencia=${guardar?.data.ausencia}&pFechaInicio=${pFechaInicial}&pFechaFin=${pFechaFinal}&opcion=2`);
      abrirPDFs(response);
      guardarArchivoBD(response);
    } catch (error) {
      console.error("Error al imprimir el documento. Notificarlo a su Coordinador de Gente.", error);
      showAlert("error", "Imprimir", error.message);
    }
  };

  const abrirPDFs = async (response) => {
    response.data.forEach((item, index) => {
      const partes = item.rutaGuardado.split("\\");
      const id = partes[partes.length - 2];
      const archivo = partes[partes.length - 1];

      setTimeout(async () => {
        try {
          const res = await api.get(`/utilidades/abrir-docs/${id}/${archivo}`, {
            responseType: 'blob'
          });
          const blob = new Blob([res.data], { type: 'application/pdf' });
          const blobUrl = URL.createObjectURL(blob);
          window.open(blobUrl, "_blank", "noopener,noreferrer");
        } catch (error) {
          console.error("Error al abrir el PDF:", error);
        }
      }, index * 500); // abre cada uno con 500ms de diferencia
    });
  };

  const guardarArchivoBD = async (response) => {
    try {
      for (const item of response.data) {
        let ruta = item.rutaGuardado.split("\\");
        let nombreArchivo = ruta[ruta.length - 1].split(".");

        const archivo = {
          clase: 14,
          referencia: ruta[5],
          nombreArchivo: nombreArchivo[0],
          extension: nombreArchivo[1],
          ruta: item.rutaGuardado,
          usuarioIU: "KIOSCO",
        }

        await api.post("/utilidades/i-adjuntos", archivo);
      }
    } catch (error) {
      console.error("Error al guardar el archivo:", error);
      showAlert("error", "Guardar Archivo", error.message);
    }
  };

  const enviarCorreo = async (guardar) => {
    const correo = {
      mensaje: "Se ha creado un nuevo Permiso/Ausentismo",
      motivo: "Vacaciones",
      descripcion: "VACACIONES",
      solicitante: empleado?.em_Name,
      colaborador: empleado?.em_Name,
      urlSolicitud: `${guardar?.data.ausencia}`,
      para: empleado?.em_CompanyEMail + ",bgodinez@productosbyb.com",
      //para: empleado?.em_CorreoJefe,
    }
    
    try {
      await api.post("/utilidades/correo-ausencias", correo);
    } catch (error) {
      console.error("Error al enviar correo:", error);
      showAlert("error", "Correo", error.message);
    }
  };

  const resetFormulario = () => {
    setFechaInicial(null);
    setFechaFinal(null);
    setDiasHabiles(0);
  };

  return (
    <Layout>
      <div className="p-3 container-fluid">
        <div className="row">
          <div className="col-lg-12 col-md-12 col-12">
            <div className="border-bottom pb-4 mb-4">
              <h3 className="mb-0 fw-bold">Ausencias y Permisos</h3>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="card-body">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div className="mb-4">
                  <h3>Crear Ausencias</h3>
                </div>
              </div>
            </div>
            <div className="row mb-4">
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Código</label>
                  <input type="text" className="form-control" value={empleado?.em_No} readOnly />
                </div>
              </div>
              <div className="col-sm-3">
                <div className="form-group">
                  <label className="form-label">Nombre</label>
                  <input type="text" className="form-control" value={empleado?.em_Name} readOnly />
                </div>
              </div>
              <div className="col-sm-2" hidden>
                <div className="form-group">
                  <label className="form-label">Código Jefe</label>
                  <input type="text" className="form-control" value={empleado?.em_CodJefe} readOnly />
                </div>
              </div>
              <div className="col-sm-3">
                <div className="form-group">
                  <label className="form-label">Nombre Jefe</label>
                  <input type="text" className="form-control" value={empleado?.em_NombreJefe} readOnly />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Días Disp. Periodo</label>
                  <input type="text" className="form-control" value={diasPeriodo} readOnly />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Días Disp. Total</label>
                  <input type="text" className="form-control" value={diasTotal} readOnly />
                </div>
              </div>
            </div>
            <div className="row mt-3 border-bottom">
              <div className="col-sm-2" hidden>
                <div className="form-group">
                  <label className="form-label">Código Gerente</label>
                  <input
                    type="text"
                    className="form-control"
                    value={codGerente}
                    readOnly
                  />
                </div>
              </div>
              <div className="col-sm-3" hidden>
                <div className="form-group">
                  <label className="form-label">Nombre Gerente</label>
                  <input
                    type="text"
                    className="form-control"
                    value={nombreGerente}
                    readOnly
                  />
                </div>
              </div>
            </div>
            <div className="row mt-3">
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Motivo Ausencia</label>
                  <SelectPicker
                    data={motivos}
                    value={motivoSeleccionado}
                    onChange={setMotivoSeleccionado}
                    searchable={false}
                    cleanable={false}
                    readOnly
                    placeholder="Seleccionar motivo..."
                  />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Tipo Permiso</label>
                  <SelectPicker
                    data={tipos}
                    value={tipoSeleccionado}
                    onChange={setTipoSeleccionado}
                    searchable={false}
                    cleanable={false}
                    readOnly
                    placeholder="Seleccionar tipo..."
                  />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Detalle Motivo</label>
                  <input type="text" className="form-control" value={detalle} readOnly />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Fecha Inicial (*)</label>
                  <DatePicker
                    shouldDisableDate={date => isBefore(date, startOfToday())}
                    value={fechaInicial}
                    onChange={setFechaInicial}
                    cleanable={false}
                    oneTap
                    format="dd/MM/yyyy"
                    placement="bottomStart"
                  />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Fecha Final (*)</label>
                  <DatePicker
                    shouldDisableDate={date => isBefore(date, startOfDay(fechaInicial))}
                    value={fechaFinal}
                    onChange={setFechaFinal}
                    cleanable={false}
                    oneTap
                    format="dd/MM/yyyy"
                    placement="bottomStart"
                  />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Días</label>
                  <input type="text" className="form-control" value={diasHabiles} readOnly />
                </div>
              </div>
            </div>
            <div className="row mt-4">
              <div className="col-sm-4 d-grid mx-auto">
                <Button
                  disabled={valido}
                  type="submit"
                  variant="outline-success"
                  className="mb-2 me-1"
                  onClick={handleGuardar}
                >{guardando ? 'Guardando...' : <>Grabar <Pocket size="18px" /></>}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Tabla de periodos */}
      <div className="p-3 container-fluid">
        <div className="card">
          <div className="card-body">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div className="mb-4">
                  <h3>Periodos Vacaciones</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <Table responsive hover className="text-nowrap">
                <thead className="table-light">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Periodo Inicio</th>
                    <th scope="col">Periodo Fin</th>
                    <th scope="col">Días Acumulados</th>
                    <th scope="col">Días Gozados</th>
                    <th scope="col">Días Pendientes</th>
                  </tr>
                </thead>
                <tbody>
                  {periodos.map((periodo, index) => (
                    <tr key={index}>
                      <th scope="row">{index + 1}</th>
                      <td>{format(new Date(periodo.periodoInicio), "dd/MM/yyyy")}</td>
                      <td>{format(new Date(periodo.periodoFin), "dd/MM/yyyy")}</td>
                      <td>{periodo.diasAcumulados}</td>
                      <td>{periodo.diasGozados}</td>
                      <td>{periodo.diasPendientes}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          </div>
        </div>
      </div>
      {/* Tabla de ausencias */}
      <div className="p-3 container-fluid">
        <div className="card">
          <div className="card-body">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div className="mb-4">
                  <h3>Ausencias Creadas</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <PaginatedComponent
                data={ausencias}
                itemsPerPage={15}
                renderItems={(currentItems) => (
                  <Table responsive hover className="text-nowrap">
                    <thead className="table-light">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Motivo</th>
                        <th scope="col">Fecha Inicio</th>
                        <th scope="col">Fecha Fin</th>
                        <th scope="col">Días</th>
                        <th scope="col">Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentItems.map((ausencia, index) => (
                        <tr key={index}>
                          <th scope="row">{index + 1}</th>
                          <td>{ausencia.ausencia}</td>
                          <td>{ausencia.empleado}</td>
                          <td>{ausencia.descMotivo}</td>
                          <td>{format(new Date(ausencia.fechaInicio), "dd/MM/yyyy")}</td>
                          <td>{format(new Date(ausencia.fechaFin), "dd/MM/yyyy")}</td>
                          <td>{ausencia.dias}</td>
                          <td>{
                            (() => {
                              switch (ausencia.estado) {
                                case 0:
                                  return <span className="badge bg-secondary">Sin Aprobar</span>;
                                case 3:
                                  return <span className="badge bg-danger">Rechazada</span>;
                                case 4:
                                  return <span className="badge bg-warning">Anulada</span>;
                                default:
                                  return <span className="badge bg-success">Aprobada</span>;
                              }
                            })()
                          }</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )}
              />
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Ausencias;
