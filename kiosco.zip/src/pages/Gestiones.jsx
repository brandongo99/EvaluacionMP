import Layout from "../components/Layout";
import { DatePicker, SelectPicker } from 'rsuite';
import { Button, Table } from 'react-bootstrap';
import { Pocket } from 'react-feather';
import { useEffect, useState, useRef } from 'react';
import { format, set } from 'date-fns';
import { showAlert, showAlertWithTimer } from '../utils/Alerts';
import api from "../utils/axiosInstance";
import 'rsuite/dist/rsuite.min.css';
import PaginatedComponent from '../components/Pagination';
import { InputMask } from 'primereact/inputmask';
import departamentosJson from '../utils/departamentos.json';

const Gestiones = () => {
  const empleado = JSON.parse(localStorage.getItem("empleado"));

  const [tipos, setTipos] = useState([]);
  const [tipoSeleccionado, setTipoSeleccionado] = useState(null);
  const [destinatario, setDestinatario] = useState("");
  const [motivoFormulario, setMotivoFormulario] = useState(null);
  const [observaciones, setObservaciones] = useState("");
  const [fechaAsistencia, setFechaAsistencia] = useState(null);
  const [fechaSolicitud, setFechaSolicitud] = useState(new Date());
  const [guardando, setGuardando] = useState(false);
  const [gestiones, setGestiones] = useState([]);
  const [guardar, setGuardar] = useState(false);
  const [valido, setValido] = useState(false);
  const [dpi, setDpi] = useState("");
  const [nombreInscribe, setNombreInscribe] = useState("");
  const [nombrePadre1, setNombrePadre1] = useState("");
  const [nombrePadre2, setNombrePadre2] = useState("");
  const [departamentos, setDepartamentos] = useState([]);
  const [departamento, setDepartamento] = useState(null); 
  const [municipios, setMunicipios] = useState([]);
  const [municipio, setMunicipio] = useState(null); 
  const textareaRef = useRef();

  const opcionesTipos = [
    { label: 'Ingresos', value: 1 },
    { label: 'Laboral', value: 2 },
    { label: 'IGSS', value: 3 },
    { label: 'IRTRA', value: 4 },
  ];

  const cargarGestiones = async () => {
    try {
      const response = await api.get(
        `/gestionesrrhh/sel-gestiones?noEmpleado=${empleado.em_No}`
      );
      setGestiones(response.data);
    } catch (error) {
      console.error("Error al obtener las gestiones:", error);
      setGestiones([]);
    }
  };

  useEffect(() => {
    try {
      setTipos(opcionesTipos);
      cargarGestiones();
      setGuardar(false);
      const deptos = departamentosJson.map((dep) => ({
        label: dep.title,
        value: dep.title
      }));
      setDepartamentos(deptos);
    } catch (error) {
      console.error("Error:", error);
      showAlert('error', '¡Error!', error.message);
    }
  }, [guardar]);

  useEffect(() => {
    if (departamento) {
      const deptoSeleccionado = departamentosJson.find((dep) => dep.title === departamento);
      if (deptoSeleccionado) {
        const munis = deptoSeleccionado.mun.map((m) => ({
          label: m,
          value: m
        }));
        setMunicipios(munis);
        setMunicipio(null);
      }
    }
  }, [departamento]);

  const handleGuardar = async () => {
    setGuardando(true);
    setValido(true);

    if (!tipoSeleccionado) {
      showAlert('warning', 'Tipo requerido', 'Debe seleccionar un tipo de gestión.');
      setGuardando(false);
      setValido(false);
      return;
    }

    if (tipoSeleccionado === 1 && !destinatario) {
      showAlert('warning', 'Destinatario requerido', 'Debe ingresar un destinatario para el tipo Ingresos.');
      setGuardando(false);
      setValido(false);
      return;
    }

    if (tipoSeleccionado === 3 && (!motivoFormulario || !fechaAsistencia)) {
      showAlert('warning', 'Campos requeridos', 'Debe llenar todos los campos para el tipo IGSS.');
      setGuardando(false);
      setValido(false);
      return;  
    }

    const gestion = {
      gestionId: null,
      empresa: empleado?.em_Company,
      codEmpleado: empleado?.em_No,
      tipo: tipoSeleccionado,
      fechaSolicitud: fechaSolicitud.toISOString(),
      estado: 1,
      destinatario: tipoSeleccionado === 1 ? destinatario.toUpperCase() : "",
      observaciones: tipoSeleccionado === 3 ? observaciones.toUpperCase() : "",
      fechaAsistencia: tipoSeleccionado === 3 && fechaAsistencia ? fechaAsistencia.toISOString() : null,
      usuarioIU: "KIOSCO",
      personaInscribe: tipoSeleccionado === 3 ? motivoFormulario : 0,
      fechaFinalizacion: null,
      codEmpleadoGestiona: empleado?.em_No,
      nombreInscribe: nombreInscribe.toUpperCase(),
      dpi: dpi,
      nombrePadre1: nombrePadre1.toUpperCase(),
      nombrePadre2: motivoFormulario === 4 ? empleado?.em_Name : nombrePadre2.toUpperCase(),
      departamento: motivoFormulario === 4 ? departamento : "",
      municipio: motivoFormulario === 4 ? municipio : ""
    };

    try {
      const guardar = await api.post("/gestionesrrhh/iu-gestiones", gestion);      
      showAlertWithTimer('success', '¡Éxito!', 'La gestión fue registrada. Tu gestión será entregada por tu Coordinador de Gente.');
      await enviarCorreo(guardar);
      resetFormulario();
      cargarGestiones();
    } catch (error) {
      showAlert('error', '¡Error!', 'Ocurrió un error al guardar la gestión.');
    } finally {
      setGuardando(false);
      setGuardar(true);
      setValido(false);
    }
  };

  const enviarCorreo = async (guardar) => {
    try {
      await api.post("/utilidades/correo-gestiones", {
        codigoEmpleado: empleado?.em_No,
        nombreEmpleado: empleado?.em_Name,
        estadoGestion: "Creada",
        fechaSolicitud: format(fechaSolicitud, "yyyy-MM-dd'T'HH:mm:ss"),
        detalles: tipoSeleccionado === 1 ? "Ingresos" : tipoSeleccionado === 2 ? "Laboral" : tipoSeleccionado === 3 ? "IGSS" : "IRTRA",
        url: `${guardar.data.gestionId}`,
        para: empleado?.em_CompanyEMail + ",bgodinez@productosbyb.com",
      });
    } catch (error) {
      console.error("Error al enviar correo:", error);
      showAlert("error", "Correo", error.message);
    }
  };

  const handleObsChange = (e) => {
    setObservaciones(e.target.value);

    const el = textareaRef.current;
    el.style.height = "auto";
    el.style.height = el.scrollHeight + "px";
  };

  const resetFormulario = () => {
    setTipoSeleccionado(null);
    setDestinatario("");
    setMotivoFormulario(null);
    setObservaciones("");
    setFechaAsistencia(null);
    setFechaSolicitud(new Date());
    setNombreInscribe("");
    setDpi("");
    setNombrePadre1("");
    setNombrePadre2("");
    setDepartamento(null);
    setMunicipio(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  return (
    <Layout>
      <div className="p-3 container-fluid">
        <div className="row">
          <div className="col-lg-12 col-md-12 col-12">
            <div className="border-bottom pb-4 mb-4">
              <h3 className="mb-0 fw-bold">Gestiones Recursos Humanos</h3>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="card-body">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div className="mb-4">
                  <h3>Crear Gestion</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Código</label>
                  <input type="text" className="form-control" value={empleado?.em_No} readOnly />
                </div>
              </div>
              <div className="col-sm-3">
                <div className="form-group">
                  <label className="form-label">Nombre</label>
                  <input type="text" className="form-control" value={empleado?.em_Name} readOnly />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Tipo (*)</label>
                  <SelectPicker
                    data={tipos}
                    value={tipoSeleccionado}
                    onChange={setTipoSeleccionado}
                    searchable={false}
                    cleanable={false}
                    placeholder="Seleccionar tipo..."
                    required
                  />
                </div>
              </div>
              <div className="col-sm-2">
                <div className="form-group">
                  <label className="form-label">Fecha (*)</label>
                  <DatePicker
                    defaultValue={new Date()}
                    oneTap
                    format="dd/MM/yyyy"
                    placement="bottomStart"
                    cleanable={false}
                    value={fechaSolicitud}
                    onChange={setFechaSolicitud}
                  />
                </div>
              </div>
              {tipoSeleccionado === 1 && (
                <div className="col-sm-3">
                  <div className="form-group">
                    <label className="form-label">Destinatario (*)</label>
                    <input
                      type="text"
                      className="form-control"
                      value={destinatario}
                      onChange={(e) => setDestinatario(e.target.value)}
                      placeholder="Ingresa destinatario..."
                    />
                  </div>
                </div>
              )}
              {tipoSeleccionado === 3 && (
                <>
                  <div className="col-sm-3">
                    <div className="form-group">
                      <label className="form-label">Motivo de Formulario (*)</label>
                      <SelectPicker
                        data={[
                          { label: "Inscripción", value: 1 },
                          { label: "Actualización", value: 2 },
                          { label: "Inscripción Cónyuge", value: 3 },
                          { label: "Inscripción Hijo(s)", value: 4 }
                        ]}
                        value={motivoFormulario}
                        onChange={setMotivoFormulario}
                        searchable={false}
                        cleanable={false}
                        placeholder="Seleccionar motivo..."
                      />
                    </div>
                  </div>                  
                  <div className="col-sm-2 mt-4">
                    <div className="form-group">
                      <label className="form-label">Fecha Asiste IGSS (*)</label>
                      <DatePicker
                        oneTap
                        format="dd/MM/yyyy"
                        placement="bottomStart"
                        value={fechaAsistencia}
                        onChange={setFechaAsistencia}
                      />
                    </div>
                  </div>
                  {(motivoFormulario === 3 || motivoFormulario === 4) && (
                    <>
                      <div className="col-sm-3 mt-4">
                        <div className="form-group">
                          <label className="form-label">Nombre Persona a Inscribir (*)</label>
                          <input 
                            type="text" 
                            className="form-control"
                            value={nombreInscribe}
                            onChange={(e) => setNombreInscribe(e.target.value)}
                            placeholder="Ingrese nombre completo..."
                          />
                        </div>
                      </div>
                      <div className="col-sm-3 mt-4">
                        <div className="form-group">
                          <label className="form-label">CUI o DPI (*)</label>
                          <InputMask 
                            className="form-control" 
                            value={dpi}
                            onChange={(e) => setDpi(e.target.value)}
                            mask="9999-99999-9999" 
                            placeholder="____-_____-____" />
                        </div>
                      </div>
                      <div className="col-sm-4 mt-4">
                        <div className="form-group">
                          <label className="form-label">{motivoFormulario === 3 ? "Nombre Padre (*)" : "Nombre Padre/Madre (*)"}</label>
                          <input 
                            type="text" 
                            className="form-control"
                            value={nombrePadre1}
                            onChange={(e) => setNombrePadre1(e.target.value)}
                            placeholder="Ingrese nombre completo..."
                          />
                        </div>
                      </div>
                    </>
                  )}
                  {motivoFormulario === 3 && (
                    <>
                      <div className="col-sm-4 mt-4">
                        <div className="form-group">
                          <label className="form-label">Nombre Madre (*)</label>
                          <input 
                            type="text" 
                            className="form-control"
                            value={nombrePadre2}
                            onChange={(e) => setNombrePadre2(e.target.value)}
                            placeholder="Ingrese nombre completo..."
                          />
                        </div>
                      </div>
                    </>
                  )}
                  {motivoFormulario === 4 && (
                    <>
                      <div className="col-sm-4 mt-4">
                        <div className="form-group">
                          <label className="form-label">Departamento Nacimiento (*)</label>
                          <SelectPicker
                            data={departamentos}
                            value={departamento}
                            onChange={setDepartamento}
                            searchable={true}
                            cleanable={false}
                            readOnly={false}
                            placeholder="Seleccionar Departamento..."
                          />
                        </div>
                      </div>
                      <div className="col-sm-4 mt-4">
                        <div className="form-group">
                          <label className="form-label">Municipio Nacimiento (*)</label>
                          <SelectPicker
                            data={municipios}
                            value={municipio}
                            onChange={setMunicipio}
                            searchable={true}
                            cleanable={false}
                            readOnly={departamento === null}
                            placeholder="Seleccionar Municipio..."
                          />
                        </div>
                      </div>
                    </>
                  )}
                  <div className="col-sm-4 mt-4">
                    <div className="form-group">
                      <label className="form-label">Observaciones</label>
                      <textarea
                        ref={textareaRef}
                        className="form-control"
                        rows="1"
                        value={observaciones}
                        onChange={handleObsChange}
                        placeholder="Si la dirección cambia por favor indiquela en este campo..."
                      />
                    </div>
                  </div>
                </>
              )}
            </div>
            <div className="row mt-4">
              <div className="col-sm-4 d-grid mx-auto">
                <Button
                  disabled={valido}
                  type="submit"
                  variant="outline-success"
                  className="mb-2 me-1"
                  onClick={handleGuardar}
                >{guardando ? 'Guardando...' : <>Grabar <Pocket size="18px" /></>}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Tabla de citas */}
      <div className="p-3 container-fluid">
        <div className="card">
          <div className="card-body">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                <div className="mb-4">
                  <h3>Gestiones Creadas</h3>
                </div>
              </div>
            </div>
            <div className="row">
              <PaginatedComponent
                data={gestiones}
                itemsPerPage={15}
                renderItems={(currentItems) => (
                  <Table responsive hover className="text-nowrap">
                    <thead className="table-light">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Fecha Solicitud</th>
                        <th scope="col">Fecha Finalización</th>
                        <th scope="col">Estado</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentItems.map((gestiones, index) => (
                        <tr key={index}>
                          <th scope="row">{index + 1}</th>
                          <td>{gestiones.no}</td>
                          <td>{gestiones.nombreEmpleado}</td>
                          <td>{gestiones.tipo}</td>
                          <td>{format(new Date(gestiones.fechaSolicitud), "dd/MM/yyyy")}</td>
                          <td>{gestiones.fechaFinalizacion !== '0001-01-01T00:00:00' ? format(new Date(gestiones.fechaFinalizacion), "dd/MM/yyyy") : ''}</td>
                          <td>{
                            (() => {
                              switch (gestiones.estado) {
                                case "Creada":
                                  return <span className="badge bg-warning">Sin Aprobar</span>;
                                case "Finalizada":
                                  return <span className="badge bg-success">Finalizada</span>;
                                default:
                                  return <span className="badge bg-secondary">Otro</span>;
                              }
                            })()
                          }</td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                )}
              />              
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Gestiones;
