import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from 'react-bootstrap';
import api from "./utils/axiosInstance";
import logoSmall from './images/BYB_Logo_Small.png';
import { saveTokens } from "./utils/authService";

const Login = () => {
  const [codigo, setCodigo] = useState("");
  const [dpi, setDpi] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await api.post("/auth/login", {
        codigo,
        dpi
      });

      const { success, message, access_token, refresh_token, empleado } = response.data;

      if (!success) {
        setError("Error al iniciar sesión: " + message);
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        localStorage.removeItem("empleado");
        return;
      }

      // Guardar tokens y datos
      saveTokens({ access_token, refresh_token });
      localStorage.setItem("empleado", JSON.stringify(empleado));

      navigate("/dashboard");
    } catch (err) {
      console.error(err);
      setError("Error al iniciar sesiónssss: " + err.message);
    }
  };

  return (
    <div className="container-fluid d-flex align-items-center justify-content-center min-vh-100 bg-light">
      <div className="card shadow p-4" style={{ maxWidth: "420px", width: "100%" }}>
        <div className="text-center mb-4">
          <img
            src={logoSmall}
            alt="BybKiosco"
            className="mb-3"
            style={{ maxHeight: "60px" }}
          />
          <p className="text-muted">Introduzca sus datos de usuario.</p>
        </div>
        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label htmlFor="codigo" className="form-label">
              Código de Empleado
            </label>
            <input
              type="text"
              id="codigo"
              className="form-control"
              value={codigo}
              onChange={(e) => setCodigo(e.target.value)}
              placeholder="Ej: 001234"
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="dpi" className="form-label">
              DPI
            </label>
            <input
              type="password"
              id="dpi"
              className="form-control"
              value={dpi}
              onChange={(e) => setDpi(e.target.value)}
              placeholder="DPI completo (sin guiones ni espacios)"
              required
            />
          </div>
          {error && <div className="alert alert-danger text-center">{error}</div>}
          <Button type="submit" variant="success" className="w-100">
            Iniciar Sesión
          </Button>
        </form>
      </div>
    </div>
  );
};

export default Login;